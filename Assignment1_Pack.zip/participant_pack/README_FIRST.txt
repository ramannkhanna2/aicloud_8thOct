WEEKLY ASSESSMENT — SESSIONS 3 & 4

1. Open Assignment_Instructions_Sessions_3_4.docx.
2. Extract starter-files and complete the tasks in the guide.
3. Create your own submission folder and zip it using the naming format in the guide.
4. Upload your submission ZIP to the course portal.

Safety reminders:
- Do NOT run terraform apply.
- Never submit credentials, secrets, Terraform state files, or raw plan files.
- Use the offline OPA option if you do not have access to the assigned AWS training credentials.
