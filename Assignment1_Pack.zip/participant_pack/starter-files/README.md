# Sessions 3 and 4 Assignment — Starter Files

This pack supports the weekly assessment on Session 3 (AI copilot/IaC and pipeline troubleshooting) and Session 4 (security checks for AI-generated Terraform).

## Files

- `main.tf` — Terraform configuration with deliberate security issues.
- `policy.rego` — OPA policy that checks S3 public-access settings, versioning, and KMS encryption.
- `codepipeline-failure-log.txt` — fictional, sanitized log excerpt for troubleshooting.
- `sample-tfplan-insecure.json` — offline sample plan that should fail the OPA policy.
- `sample-tfplan-secure.json` — offline sample plan that should pass the OPA policy after the intended fixes.

## Safety

- Do not run `terraform apply`.
- Do not upload AWS credentials, access keys, secret tokens, state files, or raw plan files to your portal.
- If using an AWS training account, use only the account/environment supplied for the course.
- If you cannot use AWS credentials, follow the offline OPA path in the assignment instructions.
