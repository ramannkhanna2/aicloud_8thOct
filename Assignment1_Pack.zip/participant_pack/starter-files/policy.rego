package terraform.security

# All S3 public access protections must be enabled.
deny contains msg if {
    rc := input.resource_changes[_]
    rc.type == "aws_s3_bucket_public_access_block"
    rc.change.after.block_public_acls != true
    msg := "SECURITY-001: S3 bucket must block public ACLs."
}

deny contains msg if {
    rc := input.resource_changes[_]
    rc.type == "aws_s3_bucket_public_access_block"
    rc.change.after.block_public_policy != true
    msg := "SECURITY-002: S3 bucket must block public bucket policies."
}

deny contains msg if {
    rc := input.resource_changes[_]
    rc.type == "aws_s3_bucket_public_access_block"
    rc.change.after.ignore_public_acls != true
    msg := "SECURITY-003: S3 bucket must ignore public ACLs."
}

deny contains msg if {
    rc := input.resource_changes[_]
    rc.type == "aws_s3_bucket_public_access_block"
    rc.change.after.restrict_public_buckets != true
    msg := "SECURITY-004: S3 bucket must restrict public buckets."
}

# S3 versioning must be enabled.
deny contains msg if {
    rc := input.resource_changes[_]
    rc.type == "aws_s3_bucket_versioning"
    rc.change.after.versioning_configuration[0].status != "Enabled"
    msg := "SECURITY-005: S3 bucket versioning must be enabled."
}

# S3 encryption must use KMS.
deny contains msg if {
    rc := input.resource_changes[_]
    rc.type == "aws_s3_bucket_server_side_encryption_configuration"
    rc.change.after.rule[0].apply_server_side_encryption_by_default[0].sse_algorithm != "aws:kms"
    msg := "SECURITY-006: S3 bucket encryption must use AWS KMS."
}
