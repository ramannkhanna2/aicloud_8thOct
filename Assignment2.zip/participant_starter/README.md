# Sessions 5 & 6 Assignment — Starter Pack

1. Read `Sessions_5_6_Assignment_Participant_Guide.docx`.
2. Copy `submission-template/` and rename the copy `YourName_Sessions5-6_Assignment/`.
3. Read the scenario files in `starter-files/`.
4. Fill the five response files in your copied submission folder.
5. Zip your completed folder and submit it to the course portal.

Estimated time: 60–90 minutes. Total: 20 marks.

**Safety:** Do not create new GPU infrastructure for this assignment, do not run `terraform apply`, and do not delete shared trainer resources. Do not include credentials, Terraform state, raw plan files, or unredacted sensitive logs. Screenshots are optional.
