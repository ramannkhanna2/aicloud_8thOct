# Scenario A1 — Bedrock foundation review

Use the Lab 5 target configuration as the requirement. In the lab, the S3 bucket should remain private, use SSE-KMS with the `aws/s3` key, the S3 endpoint is a **Gateway** endpoint, and the Bedrock Runtime endpoint is an **Interface** endpoint with private DNS enabled. The endpoint security group should allow HTTPS/443 from the Lambda security group, not the whole internet.

The following configuration has been reported during a review:

| Control | Observed setting |
|---|---|
| S3 Block Public Access | `BlockPublicAcls=true`, `IgnorePublicAcls=true`, `BlockPublicPolicy=false`, `RestrictPublicBuckets=true` |
| S3 default encryption | `AES256` (SSE-S3) |
| S3 VPC endpoint | Service `com.amazonaws.us-east-1.s3`; Type `Gateway`; route table associated with the Lambda subnet |
| Bedrock Runtime VPC endpoint | Service `com.amazonaws.us-east-1.bedrock-runtime`; Type `Interface`; Status `Available`; Private DNS disabled |
| Bedrock endpoint security group | Inbound TCP/443 source `0.0.0.0/0` |
| Lambda security group | No inbound rules |
| Workload IAM policy | `bedrock:InvokeModel` scoped to the Nova Micro model; S3 read/write permissions scoped to the lab bucket |

## Your response
Identify **four** settings that do not meet the Lab 5 target. For each one, record the observed setting, a one-sentence risk, and the correction. Do not count the correctly configured S3 Gateway endpoint, Lambda security group or scoped IAM permissions as findings.
