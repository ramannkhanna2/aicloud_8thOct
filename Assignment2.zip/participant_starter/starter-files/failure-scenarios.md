# Scenario A2 — Simulated access failures

These logs are fictional training examples. They do not represent a real account. Diagnose the permission boundary from the exact error; do not assume a network failure just because an AWS request failed.

## Failure 1 — Bedrock inference

The Bedrock Runtime interface endpoint is `Available` and private DNS is enabled. Lambda returns:

```text
AccessDeniedException: the execution role is not authorized to perform bedrock:InvokeModel on resource arn:aws:bedrock:us-east-1::foundation-model/amazon.nova-micro-v1:0 because no identity-based policy allows the bedrock:InvokeModel action
```

Answer: most likely cause, then two safe checks.

## Failure 2 — Store the generated report in S3

The private bucket and S3 Gateway endpoint exist. Lambda returns:

```text
AccessDenied: the execution role is not authorized to perform s3:PutObject on resource arn:aws:s3:::ai-cloud-lab5-demo/lab5/generated-reports/incident-example.md because no identity-based policy allows s3:PutObject
```

Answer: most likely cause, then two safe checks. Do not disable Block Public Access or grant `s3:*` on all resources.
