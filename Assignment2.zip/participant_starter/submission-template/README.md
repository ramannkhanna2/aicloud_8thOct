# Your Sessions 5 & 6 Assignment

Name: [Your name]

I completed the assignment using: [supplied scenarios / sanitized evidence from the class lab]

## Completion checklist
- [ ] A1 — Four Bedrock foundation review findings
- [ ] A2 — Both access failures diagnosed
- [ ] B1 — GPU provisioning and inference flow explained
- [ ] B2 — Pending GPU Pod interpreted and checked
- [ ] B3 — KServe/KEDA autoscaling and safe cleanup explained
- [ ] I reviewed the ZIP and removed secrets and unsafe artifacts

Screenshots are optional. Describe any lab access limitation here, if applicable: [brief note]
