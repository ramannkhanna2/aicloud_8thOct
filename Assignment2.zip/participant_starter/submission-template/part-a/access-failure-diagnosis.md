# A2 — Access-failure diagnosis

## Failure 1 — Bedrock InvokeModel
Most likely cause supported by the message:

Two safe checks:
1.
2.

Why broad permissions are not the right first fix:

## Failure 2 — S3 PutObject
Most likely cause supported by the message:

Two safe checks:
1.
2.

Why public access should remain blocked:
