# A1 — Bedrock foundation review

| Finding | Observed setting | Risk | Recommended correction |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |
| 4 | | | |
