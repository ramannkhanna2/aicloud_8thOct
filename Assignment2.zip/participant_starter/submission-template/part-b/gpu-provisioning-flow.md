# B1 — GPU provisioning and inference flow

Put the components in order and explain each step in your own words.

1. Pod GPU request and Kubernetes scheduling:
2. Karpenter and the GPU NodePool/EC2NodeClass:
3. NVIDIA device plugin and `nvidia.com/gpu`:
4. KServe Standard mode/model serving:
5. Prometheus metrics:
6. KEDA scaling model replicas:

In one or two sentences, explain the difference between node scaling and Pod/replica scaling:
