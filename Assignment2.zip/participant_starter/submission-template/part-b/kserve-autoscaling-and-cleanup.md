# B3 — KServe/KEDA autoscaling and cleanup

1. Name two checks if the model remains at one replica under load:
- Check 1:
- Check 2:

2. What do `minReplicas: 1` and `maxReplicas: 2` mean in this lab?

3. Which resource does Karpenter scale, and which replicas does KEDA scale?

4. After testing, write the cleanup commands for the load-test Pod and the `qwen-demo` InferenceService. Name at least two shared components that must not be deleted.
