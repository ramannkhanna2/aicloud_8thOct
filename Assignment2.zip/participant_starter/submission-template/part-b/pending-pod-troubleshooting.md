# B2 — Pending GPU Pod

1. Does `Pending` shortly after applying the Pod necessarily mean the lab is broken? Why?

2. What does `nvidia.com/gpu: "1"` request?

3. Give two read-only commands you would run if the Pod does not progress. For each, say what you would inspect.
- Command 1:
- What I would inspect:
- Command 2:
- What I would inspect:
