# Validation notes for the Day 10 lab bundle

## Checks completed in the build environment

- Parsed both JSON files with Python's standard `json` parser.
- Checked the CloudTrail advanced selectors semantically: one selector records management events; the second is limited to Bedrock Guardrail data events (`AWS::Bedrock::Guardrail`).
- Ran `bash -n` on every Bash helper script.
- Ran the Guardrail helper modes against a mocked AWS CLI executable and confirmed that the three commands use the expected `ApplyGuardrail` arguments, including `INPUT` and `OUTPUT` sources.
- Ran the CloudTrail helper against a mocked AWS CLI executable and confirmed that it submits the advanced selector file, starts logging, and requests status/selector verification.
- Built the sample RAG deployment package archive from the supplied manifest, listed its contents, changed a copy, and confirmed that the changed copy has a different SHA-256 digest.
- Reviewed the Cosign key-generation, blob-signing, bundle-verification and tamper-test command sequence against the current official Sigstore documentation.
- Reviewed the AWS Guardrails, `ApplyGuardrail`, CloudTrail and Security Hub instructions against current official AWS documentation.

## Checks not possible in this build environment

- No participant AWS account, IAM identity, Organizations policy, or billing context was available. Therefore Guardrail creation/testing, CloudTrail delivery, AWS Config recording, and Security Hub enablement were not executed against a live AWS account.
- The Cosign executable was not installed in the build environment, so the cryptographic sign/verify/tamper cycle was not run with the actual Cosign binary here. The included commands follow the official Cosign documentation; participants perform the cryptographic verification in Exercise B.

A blanket “100% success” guarantee would be misleading because account permissions, SCPs, AWS service enrollment, Regional availability, billing restrictions, and AWS Config/Security Hub ownership are external to the lab files. The README includes explicit pass criteria, prerequisites, cost notes, cleanup, and troubleshooting for those dependencies.
