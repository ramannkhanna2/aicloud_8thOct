#!/usr/bin/env bash
set -euo pipefail

TRAIL_NAME="${TRAIL_NAME:-day10-rag-audit-trail}"
REGION="${AWS_REGION:-us-east-1}"

aws cloudtrail put-event-selectors \
  --trail-name "$TRAIL_NAME" \
  --advanced-event-selectors file://files/cloudtrail-advanced-selectors.json \
  --region "$REGION"

aws cloudtrail start-logging --name "$TRAIL_NAME" --region "$REGION"
aws cloudtrail get-trail-status --name "$TRAIL_NAME" --region "$REGION"
aws cloudtrail get-event-selectors --trail-name "$TRAIL_NAME" --region "$REGION"
