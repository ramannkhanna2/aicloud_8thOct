#!/usr/bin/env bash
set -euo pipefail

COSIGN="${COSIGN:-./cosign.exe}"
if ! command -v tar >/dev/null 2>&1; then
  echo "ERROR: tar is required. Use Git Bash or install a compatible tar utility." >&2
  exit 2
fi
if [[ "$COSIGN" == */* ]]; then
  if [[ ! -x "$COSIGN" ]]; then
    echo "ERROR: Cosign executable not found or not executable at '$COSIGN'." >&2
    exit 2
  fi
else
  if ! command -v "$COSIGN" >/dev/null 2>&1; then
    echo "ERROR: Cosign command '$COSIGN' was not found on PATH." >&2
    exit 2
  fi
fi
if [[ -e cosign.key || -e cosign.pub ]]; then
  echo "ERROR: cosign.key or cosign.pub already exists. Back up or remove the old training key pair before generating another." >&2
  exit 2
fi

mkdir -p build
cp files/rag-model-manifest.json build/
tar -czf rag-model-package.tar.gz -C build .
"$COSIGN" generate-key-pair
"$COSIGN" sign-blob --key cosign.key --bundle rag-model-package.sigstore.json rag-model-package.tar.gz
"$COSIGN" verify-blob --key cosign.pub --bundle rag-model-package.sigstore.json rag-model-package.tar.gz

echo "SUCCESS: package signed and verified. Keep cosign.key private; do not submit it."
