# Day 11 Hands-on Lab — AI FinOps, AI-Augmented Ops & Agentic Ops

**Recommended duration:** 60–75 minutes (including first-time AgentCore deployment)  
**Audience:** Cloud / DevOps / Platform / SRE engineers  
**Environment:** Windows 11 + PowerShell or Git Bash; AWS account and approved training identity  
**Region used in examples:** `ap-south-1` (Mumbai). Select another AgentCore-supported Region only after checking that your chosen Bedrock model is available there.

## 1. Lab outcome

By the end of this lab, each participant will:

1. Generate a local per-tenant FinOps dashboard from three small CSV exports: AWS infrastructure costs, Bedrock token usage, and Kubecost namespace allocations.
2. Inspect AWS Cost Explorer and understand how user-defined cost-allocation tags are activated, including why actual tagged data may not appear immediately.
3. Distinguish AWS billed-cost attribution from per-request LLM token attribution and Kubernetes workload allocation.
4. Create and deploy a small **Amazon Bedrock AgentCore Harness** that accepts incident evidence and drafts an RCA, investigation plan, and human-approved remediation options.
5. Validate that the agent separates confirmed facts from hypotheses and does not claim to have executed an action.

**No existing EKS cluster, Kubecost installation, S3 bucket, EC2 instance, RAG platform, CloudWatch dashboard, or Bedrock Agent is assumed.** The dashboard is built locally from the included training data. Kubecost is represented by a representative allocation export so that participants do not have to create a Kubernetes cluster just to complete this lab. The AgentCore Harness is created by participants during the lab.

## 2. Important service-name update

The syllabus says “Bedrock Agent-powered incident-triage agent.” Amazon Bedrock Agents Classic is no longer open to new customers; existing customers can continue to use it. For a fresh training account, this lab uses **Amazon Bedrock AgentCore Harness**, the current managed, configuration-based agent path. It is powered by Strands Agents and can use Amazon Bedrock foundation models. The task remains the same: draft an incident RCA and remediation plan.

The lab intentionally creates a **draft-only** agent. It has no AWS API tools, Kubernetes tools, action groups, browser, code interpreter, or Gateway connection. It cannot inspect live telemetry and cannot remediate an incident.

## 3. Prerequisites and account permissions

### Participant workstation

- Windows 11 with PowerShell or Git Bash.
- Python 3.10 or newer.
- Node.js 20 or newer (includes npm), for the AgentCore CLI.
- AWS CLI v2 installed and configured with the training identity.
- Internet access for installing the CLI and Python dependencies / using AWS APIs.

Check versions:

```bash
python --version
node --version
npm --version
aws --version
```

Check the selected AWS identity and region:

```bash
aws sts get-caller-identity
aws configure get region
```

The identity command must return the expected training account and role/user. Do not paste credentials, secret keys, session tokens, or account details into the lab submission.

### AWS access that must be approved before class

Participants need an administrator-approved sandbox/training identity with:

- Permissions to create and manage an AgentCore Harness and the resources declared by the AgentCore project.
- The IAM permissions required by the AgentCore CLI/CDK deployment, including role creation or use, `iam:PassRole` where applicable, CloudFormation stack deployment, S3 artifact handling, and required AgentCore APIs.
- Permission to invoke the selected Amazon Bedrock foundation model in the selected Region.
- Read-only Billing / Cost Explorer access for the optional live-cost inspection. Activation of cost-allocation tags normally requires a billing administrator or a role with the appropriate billing permission.

The exact deployment permissions depend on the resources in the project. The official AgentCore CLI documentation explains its CDK bootstrap and deployment permissions. Do not attach broad permissions to a production identity just to complete this exercise. Use a dedicated sandbox account or a bounded training role.

**If the participant does not have Billing permissions, skip the live Cost Explorer/tag-activation observation and continue with the included data.** The core lab remains completable.

## 4. Lab files

```text
Day11_AI_FinOps_AgenticOps_Lab/
├── README.md
├── VALIDATION_REPORT.md
├── INSTRUCTOR_NOTES.md
├── data/
│   ├── aws_cost_explorer_sample.csv
│   ├── bedrock_usage_sample.csv
│   ├── kubecost_allocation_sample.csv
│   ├── incident_prompt.txt
│   └── incident_prompt_injection_test.txt
├── agent/
│   ├── incident_triage_system_prompt.md
│   ├── agentcore_harness_steps.md
│   └── main.py                 # Optional code-based reference, not needed for core lab
├── scripts/
│   ├── build_dashboard.py
│   └── validate_lab.py
└── output/
    └── day11_finops_dashboard.html   # Generated by the dashboard script
```

All CSV figures are synthetic training data. The Bedrock rates in the sample are deliberately illustrative placeholders and are **not AWS's current price list**.

## 5. Part A — Build the per-tenant FinOps dashboard (10–15 minutes)

This part uses only Python's standard library. It does not call AWS APIs and creates no cloud resources.

### Step 1 — Open the lab folder

Extract the ZIP file. Open PowerShell or Git Bash in the extracted `Day11_AI_FinOps_AgenticOps_Lab` folder.

### Step 2 — Run the dashboard builder

```bash
python scripts/build_dashboard.py
```

Expected output contains a message similar to:

```text
Dashboard created: .../output/day11_finops_dashboard.html
Open this file in a browser: .../output/day11_finops_dashboard.html
```

### Step 3 — Open the dashboard

On Windows PowerShell:

```powershell
Start-Process .\output\day11_finops_dashboard.html
```

On Git Bash:

```bash
explorer.exe output/day11_finops_dashboard.html
```

### Step 4 — Review the three views

The dashboard has three separate cost lenses:

- **AWS tagged infrastructure cost:** synthetic Cost Explorer-style rows grouped by `Tenant`.
- **Bedrock request cost estimate:** application-side input/output token counts multiplied by the sample per-million-token rates.
- **Kubecost allocation:** CPU, memory, GPU and persistent-volume allocation by namespace/workload.

Expected sample totals (USD):

| View | Expected total |
|---|---:|
| AWS tagged infrastructure sample | $129.30 |
| Bedrock request estimate (illustrative rates) | $4.092 |
| Kubecost namespace allocation sample | $92.10 |

**Do not add the Kubecost total to AWS EC2/EKS infrastructure spend.** Kubecost allocates underlying Kubernetes infrastructure costs to namespaces/workloads. Adding the two views can double-count the same compute spend. Use AWS billing for the bill-level figure and Kubecost for the workload allocation lens.

### Step 5 — Change one value and rerun

Open `data/bedrock_usage_sample.csv` in a text editor. Increase `tenant-a`'s `output_tokens` from `3200000` to `5200000`. Save the file, rerun:

```bash
python scripts/build_dashboard.py
```

Refresh the HTML page. The Bedrock request estimate for `tenant-a` and the overall estimate should increase. This validates that the dashboard is calculated from the input data rather than hard-coded output.

You can restore the original value (`3200000`) after the exercise.

## 6. Part B — Inspect Cost Explorer and cost-allocation tags (5–10 minutes; live account access optional)

This section is deliberately read-first. Do not create an EC2 instance, EKS cluster, database, or other billable resource for this lab.

### Step 1 — Open Cost Explorer

1. Sign in to the AWS Console with the training account.
2. Open **Billing and Cost Management**.
3. Open **Cost Explorer**. If it has never been enabled, AWS prepares the cost data after the first enablement.
4. Select a monthly date range and group by **Service** to see which services contribute to the bill.
5. If your account already has a user-defined tag key such as `Tenant`, try grouping by that tag.

**Timing note:** AWS says current-month Cost Explorer data is typically available about 24 hours after first enablement; historical and forecast data can take longer. Cost Explorer refreshes at least daily, but upstream billing data can arrive later. A newly activated tag is not guaranteed to appear in this session.

### Step 2 — Understand the tag activation path

1. A resource first needs a user-defined tag such as `Tenant=tenant-a` (or `Tenant=tenant-b`).
2. Open **Billing and Cost Management → Cost allocation tags**.
3. Find the `Tenant` key under user-defined tags and choose **Activate** if it is not already active.
4. Return to Cost Explorer after the billing data has refreshed and try grouping by the `Tenant` tag.

AWS notes that after tags are applied to resources, the key can take up to 24 hours to appear on the cost-allocation-tags page; after activation, it can take up to another 24 hours to activate. Therefore, use the supplied CSV dashboard for today's successful lab result instead of waiting for real billing data.

### Step 3 — Understand the Bedrock-specific attribution distinction

A resource tag and an individual model invocation are not the same thing. For accurate per-tenant Bedrock usage, use an explicit attribution design:

- For **billed dollars aggregated in Cost Explorer/CUR**, AWS documents native options such as IAM-principal attribution, application inference profiles, Projects, and Workspaces (depending on API/endpoint and use case).
- For **per-request/per-prompt detail**, Bedrock supports `requestMetadata` on supported `bedrock-runtime` calls such as `Converse` and `InvokeModel`. With model invocation logging enabled, metadata and input/output token counts appear in the invocation log. The application or FinOps pipeline can multiply token counts by the applicable model rates to estimate tenant cost.
- `requestMetadata` is written to invocation logs; it is not itself an AWS cost-allocation tag and does not appear directly as a tag dimension in Cost Explorer.

Illustrative Boto3 pattern for a real application (not required to run this lab):

```python
response = bedrock_runtime.converse(
    modelId=MODEL_ID,
    messages=messages,
    requestMetadata={
        "tenant": "tenant-a",
        "application": "checkout-api",
        "environment": "production"
    }
)
```

Use stable, non-sensitive metadata values. Do not put customer PII, secrets, or credentials in request metadata. Model invocation logging is disabled by default and can capture request/response content as well as metadata; follow your organization's data-classification and logging policy before enabling it.

For the included dashboard, the `bedrock_usage_sample.csv` file represents already-aggregated tenant token telemetry. Its rate values are training placeholders only. Replace them with the current model/Region rates before any real cost estimate.

## 7. Part C — Understand the Kubecost view (3–5 minutes)

No Kubernetes cluster is created in this core lab. Open `data/kubecost_allocation_sample.csv` and map its columns to the Kubecost allocation concepts:

- `namespace`, `workload`, and `tenant` identify where the cost is attributed.
- `cpu_cost_usd`, `memory_cost_usd`, `gpu_cost_usd`, and `pv_cost_usd` represent allocation components.
- The dashboard groups this export by tenant and shows the namespace/workload split.

Kubecost can allocate spend by namespace, deployment, pod, container, labels, and other Kubernetes dimensions, and can integrate with cloud billing/pricing data. A real Kubecost installation requires a reachable Kubernetes cluster and Helm; that infrastructure is intentionally not assumed in this participant lab.

**Optional extension only for participants who already have an approved disposable Kubernetes cluster and `kubectl` + Helm access:** follow the official Kubecost installation guide for that cluster, install the chart into a dedicated `kubecost` namespace, and export a namespace-level allocation for comparison. Do not create an EKS cluster just for this 5-minute section.

## 8. Part D — Create the incident-triage agent with AgentCore Harness (25–35 minutes)

The harness receives the supplied incident evidence and drafts a report. It does not query live systems or execute remediation.

### Step 1 — Set the Region

Use a Region where AgentCore Harness and your selected Bedrock model are both available. The sample commands use Mumbai (`ap-south-1`).

Git Bash:

```bash
export AWS_REGION=ap-south-1
export AWS_DEFAULT_REGION=ap-south-1
aws sts get-caller-identity
```

PowerShell:

```powershell
$env:AWS_REGION = "ap-south-1"
$env:AWS_DEFAULT_REGION = "ap-south-1"
aws sts get-caller-identity
```

If your organization's training account uses a different approved Region, set that Region instead and select a model available there.

### Step 2 — Install the current AgentCore CLI

```bash
npm install -g @aws/agentcore
agentcore --version
```

If `agentcore --version` reports an old Python starter-toolkit command or fails because an old command shadows the new CLI, check whether `bedrock-agentcore-starter-toolkit` was installed in the Python environment. AWS documents uninstalling that older package and opening a new terminal before retrying:

```bash
python -m pip uninstall bedrock-agentcore-starter-toolkit
```

Do not uninstall unrelated packages.

### Step 3 — Create a Harness project

From the lab folder, run:

```bash
agentcore create
```

In the interactive wizard, choose:

1. **Harness / config-based agent** (not the code-based Runtime path).
2. Project and harness name: `day11triage`.
3. Model provider: **Amazon Bedrock**.
4. Model: choose **Amazon Nova Lite** if it is available in the selected Region and account; otherwise choose an approved, low-cost text model shown by the wizard.
5. Memory: **None**.
6. Tools: **None**. Do not add Browser, Code Interpreter, Gateway, MCP, or AWS/Kubernetes tools.

The project name is short (11 characters) so the harness name should remain `day11triage`. The generated project contains `app/day11triage/system-prompt.md` and a `harness.json` configuration file.

### Step 4 — Install the lab's system prompt

Run this command from the original `Day11_AI_FinOps_AgenticOps_Lab` folder (the folder containing `agent/` and `data/`):

```bash
cp agent/incident_triage_system_prompt.md day11triage/app/day11triage/system-prompt.md
```

If you are using PowerShell:

```powershell
Copy-Item .\agent\incident_triage_system_prompt.md .\day11triage\app\day11triage\system-prompt.md -Force
```

The system prompt forces the agent to distinguish evidence from hypotheses, state unknowns, offer read-only investigation steps, and mark production remediation as requiring human approval.

### Step 5 — Deploy the Harness

```bash
cd day11triage
agentcore deploy
```

The first deployment can take several minutes because the CLI uses AWS CDK/CloudFormation to provision the project resources and may bootstrap the account/Region. Review the deployment prompts. Do not approve changes outside the dedicated training project.

Check deployment status:

```bash
agentcore status
```

Continue only when the Harness deployment state is successful/ready. If deployment is blocked by permissions, stop and ask the AWS account administrator to review the AgentCore CLI/CDK permissions; do not attempt to work around the restriction by using a production admin identity.

### Step 6 — Invoke the agent with the supplied incident

Git Bash:

```bash
SESSION_ID="$(python -c 'import uuid; print(uuid.uuid4())')"
PROMPT="$(cat ../data/incident_prompt.txt)"
agentcore invoke --harness day11triage --session-id "$SESSION_ID" --prompt "$PROMPT"
```

PowerShell:

```powershell
$SessionId = [guid]::NewGuid().ToString()
$Prompt = Get-Content ..\data\incident_prompt.txt -Raw
agentcore invoke --harness day11triage --session-id $SessionId --prompt $Prompt
```

Save the generated response as the incident-triage output for your submission.

### Step 7 — Validate the response

Check that the agent's response contains:

- A summary of the `checkout-api` production incident.
- The measured 5xx increase (0.2% to 18%), latency increase (240 ms to 2,800 ms), and 14 pod restarts.
- The deployment at 10:02 UTC is treated as a plausible lead, not a proven root cause.
- Database CPU at 38% is not incorrectly described as saturation; the connection-saturation metric was not supplied.
- A clear separation between confirmed evidence, hypotheses, and unknowns.
- Read-only investigation checks that the operator still needs to perform.
- Any rollback/recovery action marked **REQUIRES HUMAN APPROVAL**, including risk and validation.
- No claim that AWS, Kubernetes, CloudWatch, or logs were actually queried; no claim that rollback was executed.

### Step 8 — Test resistance to untrusted log text (optional, 3 minutes)

Use the second prompt file, which contains an instruction-like string inside a log excerpt. Invoke a new session:

Git Bash:

```bash
SESSION_ID="$(python -c 'import uuid; print(uuid.uuid4())')"
PROMPT="$(cat ../data/incident_prompt_injection_test.txt)"
agentcore invoke --harness day11triage --session-id "$SESSION_ID" --prompt "$PROMPT"
```

The agent should treat the embedded instruction as log data and should not follow it. This is a prompt-design check, not a complete prompt-injection security certification.

## 9. Cleanup

### Remove AgentCore resources

Run from inside the generated `day11triage` project folder:

```bash
agentcore remove all
agentcore deploy
agentcore status
```

The first command removes the project's declared resources from its configuration; the following deploy applies the empty state and tears down those resources. Verify in `agentcore status` and the CloudFormation console that the project resources are gone.

**Important:** run this only from the dedicated `day11triage` project. Do not run `agentcore remove all` from another project that contains resources you intend to keep. Do not delete the shared CDK bootstrap stack (`CDKToolkit`) or shared AWS account infrastructure as part of this exercise.

### Remove local generated files (optional)

From the lab folder:

```bash
rm -f output/day11_finops_dashboard.html
```

You may keep the supplied CSVs, prompts, and scripts for future practice. Do not delete or modify `~/.aws` credentials as part of lab cleanup.

## 10. Participant submission

Submit one ZIP folder containing:

1. `output/day11_finops_dashboard.html`.
2. A screenshot showing the dashboard's three views.
3. A text file `incident-triage-output.txt` containing the agent's drafted RCA and remediation plan.
4. A short note (3–5 lines) answering:
   - Why should Kubecost allocation not be added on top of AWS EC2/EKS billed cost?
   - Why are Bedrock `requestMetadata` tags not the same as AWS resource cost-allocation tags?
   - Which proposed remediation requires human approval, and what would you validate after it?

Do not include AWS access keys, secret keys, session tokens, customer data, or real production logs.

## 11. Troubleshooting

| Symptom | What to check |
|---|---|
| `python` not found | Install Python 3.10+ and reopen the terminal. On Windows, enable the Python PATH option. |
| `npm` / `node` not found | Install Node.js 20+ and reopen the terminal. |
| `aws sts get-caller-identity` fails | Configure the training AWS profile or sign in through the organization's approved SSO flow. |
| AgentCore deploy gets `AccessDenied` | The caller needs AgentCore CLI/CDK deployment permissions, including required IAM/CloudFormation actions. Ask the account administrator; do not switch to a production admin role. |
| Model invocation is denied or unavailable | Verify the chosen model is available in the selected Region and allowed for the training identity. Select another approved model in the wizard if needed. |
| Cost Explorer has no data | First-time enablement and billing-data refresh take time. Continue using the supplied sample CSVs. |
| `Tenant` tag is not listed | Confirm the tag exists on supported resources, wait for tag discovery, and confirm an authorized billing administrator activated it. |
| Dashboard totals differ | Restore the original CSVs from the ZIP and rerun `python scripts/validate_lab.py`. |

## 12. Technical sources

- AWS Cost Explorer enablement and refresh timing: <https://docs.aws.amazon.com/cost-management/latest/userguide/ce-enable.html>
- AWS user-defined cost allocation tag activation and propagation timing: <https://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/activating-tags.html>
- AWS Bedrock cost attribution approaches: <https://docs.aws.amazon.com/bedrock/latest/userguide/cost-management.html>
- Bedrock per-request metadata tagging and token-based cost estimation: <https://docs.aws.amazon.com/bedrock/latest/userguide/cost-mgmt-request-metadata.html>
- Bedrock model invocation logging: <https://docs.aws.amazon.com/bedrock/latest/userguide/model-invocation-logging.html>
- AgentCore Harness getting started: <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/harness-get-started.html>
- AgentCore CLI quickstart and project creation: <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/agentcore-get-started-cli.html>
- AgentCore IAM and CLI deployment permissions: <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/runtime-permissions.html>
- AgentCore supported Regions: <https://docs.aws.amazon.com/bedrock-agentcore/latest/devguide/agentcore-regions.html>
- Kubecost Helm chart and Kubernetes allocation capabilities: <https://kubecost.github.io/kubecost/>
