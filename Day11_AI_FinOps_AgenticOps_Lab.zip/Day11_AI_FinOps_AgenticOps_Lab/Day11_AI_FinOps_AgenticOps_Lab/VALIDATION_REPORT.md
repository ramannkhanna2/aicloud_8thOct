# Day 11 Lab — Validation Report

## Local validation performed

The lab validation script checks that all required participant files exist; all three CSV files parse; the expected training totals are calculated; the AgentCore/Strands reference Python file parses; the system prompt contains safety constraints; and the HTML dashboard is generated with the expected headings and KPI values.

Command:

```bash
python scripts/validate_lab.py
```

Expected validation summary:

- Required files exist.
- CSV inputs parse and row counts match.
- AWS sample total = **$129.30**.
- Bedrock token-cost estimate = **$4.092** (illustrative rates only).
- Kubecost allocation total = **$92.10** (separate allocation view).
- AgentCore/Strands Python source syntax is valid.
- Incident prompt and safety constraints are present.
- Dashboard generated at `output/day11_finops_dashboard.html`.

## What was not live-tested

This environment does not contain the participants' AWS credentials, IAM role, model entitlements, organization SCPs, or billing account. Therefore, this validation does **not** claim to have deployed an AgentCore Harness, called a Bedrock model, enabled Cost Explorer, activated billing tags, installed Kubecost, or verified a real AWS invoice.

Before delivery, the instructor should execute the AgentCore Harness create/deploy/invoke/cleanup sequence once in the actual training account and verify that the training IAM role can bootstrap/deploy the project and invoke the chosen model in the selected Region.
