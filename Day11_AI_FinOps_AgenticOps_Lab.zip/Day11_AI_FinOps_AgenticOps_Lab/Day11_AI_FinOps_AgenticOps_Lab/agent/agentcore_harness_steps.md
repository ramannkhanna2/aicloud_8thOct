# AgentCore Harness setup notes

This lab uses the current Amazon Bedrock AgentCore Harness path. Amazon Bedrock Agents Classic is not open to new customers; existing customers may continue using it. The harness is configured with a Bedrock model and a system prompt, with no external tools, gateways, or action groups.

1. Install the current CLI: `npm install -g @aws/agentcore`.
2. Run `agentcore create` and choose a config-based Harness project.
3. Project/harness name: `day11triage`.
4. Model provider: Amazon Bedrock. Choose a model available in the chosen AgentCore region. A low-cost text model such as Amazon Nova Lite is suitable where available; confirm the model identifier in the current model picker.
5. Memory: None. Tools: None. Do not add a browser, code interpreter, gateway, AWS API tool, or action group.
6. In the generated project, replace `app/day11triage/system-prompt.md` with the complete contents of `agent/incident_triage_system_prompt.md` from this lab pack.
7. Run `agentcore deploy`, wait for successful completion, then `agentcore status`.
8. Invoke using the provided incident prompt file and a fresh session ID.

The deploy command uses AWS CDK/CloudFormation to provision the resources declared by the project. The caller needs AgentCore CLI, IAM role/pass-role, CDK bootstrap, CloudFormation, and related deployment permissions. Use a dedicated sandbox account and an administrator-approved training role. Do not attach broad permissions to a production identity merely to complete this exercise.
