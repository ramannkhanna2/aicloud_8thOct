#!/usr/bin/env python3
"""Build a self-contained Day 11 AI FinOps dashboard from the supplied CSV files.

Uses only the Python standard library. The input data is synthetic training data,
not a live AWS bill, Bedrock invoice, or Kubecost API response.
"""
from __future__ import annotations

import csv
import html
import json
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUTPUT = ROOT / "output" / "day11_finops_dashboard.html"


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.is_file():
        raise FileNotFoundError(f"Required input file not found: {path}")
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows:
        raise ValueError(f"No data rows found in {path.name}")
    return rows


def money(value: float) -> str:
    return f"${value:,.2f}"


def safe(value: object) -> str:
    return html.escape(str(value), quote=True)


def build() -> Path:
    ce_rows = read_csv(DATA / "aws_cost_explorer_sample.csv")
    llm_rows = read_csv(DATA / "bedrock_usage_sample.csv")
    kc_rows = read_csv(DATA / "kubecost_allocation_sample.csv")

    aws_by_tenant: dict[str, float] = defaultdict(float)
    aws_by_service: dict[str, float] = defaultdict(float)
    for row in ce_rows:
        cost = float(row["cost_usd"])
        if cost < 0:
            raise ValueError("AWS cost sample contains a negative cost")
        aws_by_tenant[row["tenant"]] += cost
        aws_by_service[row["service"]] += cost

    llm_by_tenant: dict[str, float] = defaultdict(float)
    llm_details: list[dict[str, object]] = []
    for row in llm_rows:
        requests = int(row["requests"])
        input_tokens = int(row["input_tokens"])
        output_tokens = int(row["output_tokens"])
        input_rate = float(row["input_rate_usd_per_million"])
        output_rate = float(row["output_rate_usd_per_million"])
        if min(requests, input_tokens, output_tokens) < 0 or min(input_rate, output_rate) < 0:
            raise ValueError("Bedrock usage sample contains a negative value")
        input_cost = input_tokens / 1_000_000 * input_rate
        output_cost = output_tokens / 1_000_000 * output_rate
        total = input_cost + output_cost
        llm_by_tenant[row["tenant"]] += total
        llm_details.append({
            "tenant": row["tenant"],
            "model": row["model_id"],
            "requests": requests,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "input_cost": input_cost,
            "output_cost": output_cost,
            "total": total,
            "rate_note": row["rate_note"],
        })

    kc_by_tenant: dict[str, float] = defaultdict(float)
    kc_details: list[dict[str, object]] = []
    for row in kc_rows:
        components = [float(row[name]) for name in (
            "cpu_cost_usd", "memory_cost_usd", "gpu_cost_usd", "pv_cost_usd"
        )]
        if min(components) < 0:
            raise ValueError("Kubecost sample contains a negative allocation")
        total = sum(components)
        kc_by_tenant[row["tenant"]] += total
        kc_details.append({
            "tenant": row["tenant"],
            "namespace": row["namespace"],
            "workload": row["workload"],
            "cpu": components[0],
            "memory": components[1],
            "gpu": components[2],
            "pv": components[3],
            "total": total,
        })

    tenants = sorted(set(aws_by_tenant) | set(llm_by_tenant) | set(kc_by_tenant))
    aws_total = sum(aws_by_tenant.values())
    llm_total = sum(llm_by_tenant.values())
    kc_total = sum(kc_by_tenant.values())

    def bar_rows(values: dict[str, float], title: str) -> str:
        maximum = max(values.values(), default=1.0) or 1.0
        parts = [f'<h3>{safe(title)}</h3><div class="bars">']
        for name, value in sorted(values.items(), key=lambda item: item[1], reverse=True):
            width = max(1.0, value / maximum * 100.0)
            parts.append(
                '<div class="bar-row"><div class="bar-label">'
                f'{safe(name)}</div><div class="bar-track"><div class="bar-fill" '
                f'style="width:{width:.2f}%"></div></div><div class="bar-value">{money(value)}</div></div>'
            )
        parts.append("</div>")
        return "".join(parts)

    tenant_rows = "".join(
        "<tr>"
        f"<td>{safe(t)}</td><td>{money(aws_by_tenant.get(t, 0.0))}</td>"
        f"<td>{money(llm_by_tenant.get(t, 0.0))}</td>"
        "</tr>"
        for t in tenants
    )
    service_rows = "".join(
        f"<tr><td>{safe(s)}</td><td>{money(v)}</td></tr>"
        for s, v in sorted(aws_by_service.items(), key=lambda item: item[1], reverse=True)
    )
    kc_rows_html = "".join(
        "<tr>"
        f"<td>{safe(r['tenant'])}</td><td>{safe(r['namespace'])}</td>"
        f"<td>{safe(r['workload'])}</td><td>{money(float(r['cpu']))}</td>"
        f"<td>{money(float(r['memory']))}</td><td>{money(float(r['gpu']))}</td>"
        f"<td>{money(float(r['pv']))}</td><td><strong>{money(float(r['total']))}</strong></td>"
        "</tr>"
        for r in kc_details
    )
    llm_rows_html = "".join(
        "<tr>"
        f"<td>{safe(r['tenant'])}</td><td>{safe(r['model'])}</td>"
        f"<td>{int(r['requests']):,}</td><td>{int(r['input_tokens']):,}</td>"
        f"<td>{int(r['output_tokens']):,}</td><td>{money(float(r['input_cost']))}</td>"
        f"<td>{money(float(r['output_cost']))}</td><td><strong>{money(float(r['total']))}</strong></td>"
        "</tr>"
        for r in llm_details
    )

    html_doc = f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Day 11 | AI FinOps Dashboard</title>
<style>
:root{{--ink:#182230;--muted:#526174;--line:#d8dee8;--panel:#fff;--bg:#f4f6fa;--accent:#2857a4;}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 Segoe UI,Arial,sans-serif}}
main{{max-width:1180px;margin:28px auto;padding:0 20px}}h1{{margin:0 0 4px;font-size:28px}}h2{{margin:28px 0 12px;font-size:20px}}h3{{margin:12px 0;font-size:16px}}
.sub{{color:var(--muted);margin:0 0 20px}}.grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px}}
.card{{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px}}.kpi{{font-size:24px;font-weight:700;margin-top:5px}}
.note{{background:#fff8df;border:1px solid #e8d58f;border-radius:10px;padding:12px 14px;margin:18px 0;color:#57450b}}
.panel{{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px;margin:14px 0;overflow-x:auto}}
table{{border-collapse:collapse;width:100%;min-width:650px}}th,td{{padding:9px 10px;border-bottom:1px solid var(--line);text-align:left;white-space:nowrap}}th{{background:#f0f3f8;font-weight:600}}
.bars{{display:grid;gap:10px}}.bar-row{{display:grid;grid-template-columns:minmax(130px,190px) 1fr 85px;gap:10px;align-items:center}}.bar-label{{overflow-wrap:anywhere;color:var(--muted)}}
.bar-track{{height:14px;background:#e9edf4;border-radius:8px;overflow:hidden}}.bar-fill{{height:100%;background:var(--accent);border-radius:8px}}.bar-value{{text-align:right;font-variant-numeric:tabular-nums}}
.small{{font-size:13px;color:var(--muted)}}footer{{padding:22px 0;color:var(--muted);font-size:13px}}
@media(max-width:620px){{main{{padding:0 12px}}.bar-row{{grid-template-columns:105px 1fr 72px;gap:6px}}}}
</style></head><body><main>
<h1>AI FinOps — Per-Tenant Cost View</h1>
<p class="sub">Training dataset: October 2026 · Generated locally from the three CSV files in this lab</p>
<div class="note"><strong>Important:</strong> These are synthetic figures. Bedrock token rates are illustrative placeholders, not live AWS prices. Kubecost allocations are a separate workload-allocation view and must not be added to AWS EC2/EKS bill totals; doing so can double-count the same compute spend.</div>
<div class="grid">
<div class="card"><div class="small">AWS tagged infrastructure cost (sample)</div><div class="kpi">{money(aws_total)}</div><div class="small">Cost Explorer-style sample rows</div></div>
<div class="card"><div class="small">Estimated Bedrock request cost (sample)</div><div class="kpi">{money(llm_total)}</div><div class="small">Tenant-level token telemetry × example rates</div></div>
<div class="card"><div class="small">Kubecost allocated cluster cost (sample)</div><div class="kpi">{money(kc_total)}</div><div class="small">CPU + memory + GPU + persistent volume</div></div>
</div>
<h2>1. AWS Cost Explorer-style view</h2>
<div class="panel">{bar_rows(dict(aws_by_tenant), 'Tagged infrastructure cost by tenant')}
<h3>Cost by AWS service</h3><table><thead><tr><th>Service</th><th>Cost (USD)</th></tr></thead><tbody>{service_rows}</tbody></table></div>
<div class="panel"><h3>Per-tenant finance view</h3><table><thead><tr><th>Tenant</th><th>AWS tagged infrastructure cost</th><th>Estimated Bedrock request cost</th></tr></thead><tbody>{tenant_rows}</tbody></table>
<p class="small">The Bedrock estimate comes from application-side token usage records, not an assumption that individual Bedrock requests are automatically grouped by an AWS resource tag.</p></div>
<h2>2. Bedrock token economics</h2>
<div class="panel"><table><thead><tr><th>Tenant</th><th>Model</th><th>Requests</th><th>Input tokens</th><th>Output tokens</th><th>Input estimate</th><th>Output estimate</th><th>Total estimate</th></tr></thead><tbody>{llm_rows_html}</tbody></table>
<p class="small">Formula: (input tokens ÷ 1,000,000 × input rate) + (output tokens ÷ 1,000,000 × output rate). Replace sample rates with the current region/model rates before using real usage.</p></div>
<h2>3. Kubecost namespace/workload allocation view</h2>
<div class="panel">{bar_rows(dict(kc_by_tenant), 'Allocated Kubernetes cost by tenant (separate lens)')}
<table><thead><tr><th>Tenant</th><th>Namespace</th><th>Workload</th><th>CPU</th><th>Memory</th><th>GPU</th><th>PV</th><th>Allocated total</th></tr></thead><tbody>{kc_rows_html}</tbody></table>
<p class="small">A live Kubecost installation can allocate cost by namespace, workload, pod, and container. This lab uses a representative export so that no EKS/Kubernetes cluster is required.</p></div>
<footer>Generated by scripts/build_dashboard.py · No AWS APIs are called by this dashboard generator.</footer>
</main></body></html>'''

    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(html_doc, encoding="utf-8")
    return OUTPUT


if __name__ == "__main__":
    path = build()
    print(f"Dashboard created: {path}")
    print(f"Open this file in a browser: {path}")
