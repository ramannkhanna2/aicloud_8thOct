#!/usr/bin/env python3
"""Local validation for the Day 11 lab. Does not call AWS or deploy services."""
from __future__ import annotations

import ast
import csv
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def rows(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def main() -> int:
    required = [
        ROOT / "data/aws_cost_explorer_sample.csv",
        ROOT / "data/bedrock_usage_sample.csv",
        ROOT / "data/kubecost_allocation_sample.csv",
        ROOT / "data/incident_prompt.txt",
        ROOT / "agent/incident_triage_system_prompt.md",
        ROOT / "agent/agentcore_harness_steps.md",
        ROOT / "scripts/build_dashboard.py",
    ]
    missing = [str(p.relative_to(ROOT)) for p in required if not p.is_file()]
    if missing:
        raise FileNotFoundError("Missing required lab files: " + ", ".join(missing))

    ce = rows(ROOT / "data/aws_cost_explorer_sample.csv")
    llm = rows(ROOT / "data/bedrock_usage_sample.csv")
    kc = rows(ROOT / "data/kubecost_allocation_sample.csv")
    assert len(ce) == 12, f"Expected 12 AWS cost rows, got {len(ce)}"
    assert len(llm) == 3, f"Expected 3 Bedrock telemetry rows, got {len(llm)}"
    assert len(kc) == 6, f"Expected 6 Kubecost allocation rows, got {len(kc)}"

    aws_total = sum(float(r["cost_usd"]) for r in ce)
    llm_total = sum(
        int(r["input_tokens"]) / 1_000_000 * float(r["input_rate_usd_per_million"])
        + int(r["output_tokens"]) / 1_000_000 * float(r["output_rate_usd_per_million"])
        for r in llm
    )
    kc_total = sum(
        sum(float(r[k]) for k in ("cpu_cost_usd", "memory_cost_usd", "gpu_cost_usd", "pv_cost_usd"))
        for r in kc
    )
    assert round(aws_total, 2) == 129.30, f"Unexpected AWS sample total: {aws_total}"
    assert round(llm_total, 3) == 4.092, f"Unexpected LLM sample total: {llm_total}"
    assert round(kc_total, 2) == 92.10, f"Unexpected Kubecost sample total: {kc_total}"

    # Syntax-check the AgentCore/Strands sample without importing cloud SDKs.
    agent_source = (ROOT / "agent/main.py").read_text(encoding="utf-8")
    ast.parse(agent_source, filename="agent/main.py")
    prompt = (ROOT / "agent/incident_triage_system_prompt.md").read_text(encoding="utf-8")
    incident = (ROOT / "data/incident_prompt.txt").read_text(encoding="utf-8")
    assert "never execute" in prompt.lower()
    assert "checkout-api" in incident
    assert "ignore" in prompt.lower() or "untrusted" in prompt.lower()

    # Import and run the dashboard generator.
    spec = importlib.util.spec_from_file_location("day11_dashboard", ROOT / "scripts/build_dashboard.py")
    if spec is None or spec.loader is None:
        raise RuntimeError("Could not load dashboard builder")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    output = module.build()
    html = output.read_text(encoding="utf-8")
    for marker in ("AI FinOps", "$129.30", "$4.09", "$92.10", "tenant-a", "Kubecost"):
        assert marker in html, f"Dashboard output missing expected marker: {marker}"

    print("PASS: Required files exist")
    print("PASS: CSV inputs parse and row counts match")
    print(f"PASS: AWS sample total = ${aws_total:.2f}")
    print(f"PASS: Bedrock token-cost estimate = ${llm_total:.3f} (illustrative rates)")
    print(f"PASS: Kubecost allocation total = ${kc_total:.2f} (separate allocation view)")
    print("PASS: AgentCore/Strands Python source syntax is valid")
    print("PASS: Incident prompt and safety constraints are present")
    print(f"PASS: Dashboard generated: {output.relative_to(ROOT)}")
    print("NOTE: This local validation does not deploy AgentCore or verify AWS IAM/model access.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
