# Day 9 Practical Lab - A Simple MLOps Lifecycle on AWS

**Duration:** 4 hours  
**Audience:** Cloud, DevOps, Platform and SRE engineers  
**AWS Region:** Choose one region that supports SageMaker XGBoost training and real-time endpoints. Use the same region for the whole lab.  
**Starting point:** An AWS account and permission to create the temporary resources in this guide. No SageMaker, S3, IAM, MLflow, EKS, ECR or Kubernetes resources are assumed to exist.

## 1. What participants will build

Participants will create a small, end-to-end MLOps workflow:

1. Create an encrypted S3 bucket, a SageMaker execution role and a SageMaker Model Registry group using the included CloudFormation template.
2. Upload a small prepared Iris dataset to the new S3 bucket.
3. Create a SageMaker Pipeline with two steps: **Train model** and **Register model**.
4. Run the same pipeline twice with a different `max_depth` parameter to create two model versions.
5. Review and manually approve the two model versions in SageMaker Model Registry.
6. Deploy version 1 to a real-time SageMaker endpoint.
7. Update the endpoint to version 2 using SageMaker-managed blue/green deployment with all-at-once traffic shifting.
8. Invoke the endpoint before and after the update, then delete the resources created by the lab.

The learning objective is the lifecycle, not data science: **repeatable training -> model versioning -> approval -> controlled production release**.

## 2. Deliberately excluded from the four-hour build

The Day 9 syllabus also names MLflow, KServe and CodePipeline/CodeBuild. To avoid infrastructure setup dominating a four-hour beginner-friendly practical, this core lab does not create those services:

- **MLflow:** Explain as an experiment-tracking option for recording parameters, metrics and artifacts. Participants do not create MLflow runs in this practical. They use SageMaker Pipeline execution history to compare the two parameterized runs and Model Registry to manage the resulting model versions.
- **KServe:** Explain as a Kubernetes model-serving option. Participants do not build an EKS cluster or install KServe. That deserves a separate Kubernetes lab.
- **CodePipeline/CodeBuild:** Explain how a source change can trigger the pipeline automatically. Participants manually start the pipeline in this practical so they can clearly observe its two steps.

The practical still teaches the core Day 9 MLOps idea and includes actual pipeline execution, model registration, manual approval and a blue/green endpoint update. It is intentionally not a full build of every technology in the broader Day 9 list.

## 3. What is and is not assumed

### Starting requirements

- An AWS account in which participants are allowed to create the resources listed below.
- Browser access to the AWS Management Console.
- AWS CloudShell enabled for the account and region.
- Internet access from CloudShell to install the pinned SageMaker Python SDK and its dependencies.
- A region in which the selected SageMaker XGBoost built-in algorithm image and `ml.m5.large` training/hosting instance types are available.
- SageMaker quota for at least one `ml.m5.large` training job and enough real-time endpoint quota/capacity for the blue/green update. Blue/green may temporarily keep the old and new fleets running together; check the quota in the target Region before class.
- An AWS identity that is permitted to create the CloudFormation resources in this lab, pass the generated execution role to SageMaker, create/run SageMaker pipelines and training jobs, create/approve model packages, create/update/delete endpoints and models, upload/list the lab S3 objects, and invoke the endpoint.

**No AWS resource is assumed to pre-exist.** Participants create the lab S3 bucket, IAM execution role, Model Registry group, pipeline, model versions, endpoint and endpoint configurations during the exercise. CloudFormation is used to create the initial bucket/role/model-group resources consistently; it is not a pre-created environment.

**Permission reality:** the lab cannot grant permissions to the identity that is already signed in. In a dedicated disposable training account, the simplest cohort setup is a time-limited training permission set with sufficient administrative permissions. In a controlled enterprise account, the administrator must grant the caller the equivalent CloudFormation, IAM role creation/attachment, `iam:PassRole`, S3, and SageMaker actions before the session. Account SCPs and permission boundaries can still deny these actions. Do not use a production account.

### Important permission note

For a time-boxed class, use a dedicated training account or a temporary training role with the necessary permissions. Do not use a production account. The CloudFormation template creates an execution role with `AmazonSageMakerFullAccess` plus explicit read/write access to the bucket created by this lab. The participant's own signed-in identity needs `iam:PassRole` for that generated role, because it passes the role to SageMaker when creating the pipeline and model. The role's trust policy allows the SageMaker service to assume it; it does not grant permissions to the participant identity.

If the account is governed by an organization SCP, permission boundary, permission set, or service control policy, those controls must permit the required actions. A script cannot bypass an account-level deny.

## 4. Four-hour class plan

- **00:00-00:15:** Explain the MLOps lifecycle and target architecture. Outcome: understand why a repeatable pipeline and registry are useful.
- **00:15-00:30:** Open CloudShell, select the Region, and verify identity/Python. Outcome: confirm the starting environment.
- **00:30-00:50:** Deploy the CloudFormation stack. Outcome: create the bucket, execution role and model group.
- **00:50-01:00:** Upload the prepared dataset. Outcome: verify the two CSV files in S3.
- **01:00-01:20:** Create the SageMaker Pipeline. Outcome: see the two pipeline steps and the parameter.
- **01:20-02:00:** Run the pipeline twice. Outcome: create two model package versions.
- **02:00-02:10:** Break.
- **02:10-02:25:** Review and approve model packages. Outcome: understand the manual governance gate.
- **02:25-03:05:** Deploy model version 1. Outcome: create an endpoint and run a prediction.
- **03:05-03:35:** Update to model version 2. Outcome: observe a managed blue/green update.
- **03:35-03:45:** Review the architecture and MLOps concepts. Outcome: connect pipeline, registry and release control.
- **03:45-04:00:** Clean up. Outcome: delete the endpoint and lab resources.

AWS job and endpoint start times vary by region, account quota and service load. The trainer should complete one end-to-end rehearsal in the exact training account/region before class. If the account cannot provide the endpoint quota or permissions, do not start the hands-on deployment section until that issue is resolved.

## 5. Participant instructions - follow in order

### Step 1 - Open AWS CloudShell

1. Sign in to the AWS Management Console.
2. Select the AWS Region approved for the class from the region selector in the top navigation bar.
3. Open **CloudShell** using the terminal icon in the Console navigation bar.
4. Wait until the shell prompt appears.

Run:

```bash
aws --version
aws sts get-caller-identity
aws configure get region
python3 --version
```

`aws sts get-caller-identity` must return the account and identity you are meant to use. If the configured region is empty, set it to the same region selected in the Console. Example only:

```bash
export AWS_REGION=ap-south-1
```

Do not copy the example region blindly. Use the region chosen by the trainer.

### Step 2 - Upload and unpack the lab ZIP

On your computer, download `Day9_Simple_MLOps_Lab.zip`. In CloudShell, choose **Actions -> Upload file**, upload the ZIP, and then run:

```bash
unzip Day9_Simple_MLOps_Lab.zip -d day9-lab
cd day9-lab/day9_simple_mlops_lab
```

If the extracted folder name differs, run `ls` and `cd` into the folder containing `README.md`, `data`, `infrastructure` and `scripts`.

### Step 3 - Prepare Python 3.11 and install the SDK

SageMaker Python SDK V3 requires Python 3.10 or later. CloudShell's system Python can be older, so the following commands use the separately named Python 3.11 runtime and do not replace the system Python. CloudShell's Python packages and available versions can change; verify the command output rather than assuming a particular preinstalled interpreter.

Check whether Python 3.11 is present:

```bash
python3.11 --version
```

If the command is not found, install it in CloudShell:

```bash
sudo dnf install -y python3.11 python3.11-pip
```

Create and activate a virtual environment, then install the pinned SDK:

```bash
python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python --version
python -c "import sagemaker, boto3; print('SageMaker SDK:', sagemaker.__version__); print('boto3:', boto3.__version__)"
```

Expected: Python 3.11.x and SageMaker SDK 3.28.0. Keep this CloudShell session and virtual environment active while doing the Python steps. The SDK V3 requires Python 3.10 or later; the current package metadata lists Python 3.10, 3.11 and 3.12 as supported test versions.

### Step 4 - Create AWS resources

Set the region to the region selected in the Console and choose a unique stack name for your participant (especially when the class shares one AWS account). Use only lowercase letters, numbers and hyphens; the name must be 1-32 characters and start/end with a letter or number. Example values only:

```bash
export AWS_REGION=ap-south-1
export STACK_NAME=day9-learner01
```

Every participant using the same AWS account must use a different `STACK_NAME`. The stack name is also used to generate unique pipeline, endpoint and IAM role names.

Validate the CloudFormation template syntax and create the stack:

```bash
aws cloudformation validate-template \
  --template-body file://infrastructure/day9-mlops-stack.yaml \
  --region "$AWS_REGION"

bash scripts/01_setup.sh
```

The script creates these resources from scratch:

The stack creates three resources:

- **S3 bucket:** stores the prepared dataset and model artifacts.
- **IAM execution role:** gives SageMaker the permissions needed to read the input data and write model artifacts.
- **SageMaker Model Package Group:** stores the model versions registered by the pipeline.

The script creates a `.env` file containing the generated bucket name, role ARN, model group and S3 data paths. Do not share this file publicly; it contains resource identifiers for your account (not credentials).

Confirm the setup output shows all three resource names. If CloudFormation fails, inspect the stack events before retrying:

```bash
aws cloudformation describe-stack-events \
  --stack-name "$STACK_NAME" \
  --region "$AWS_REGION" \
  --max-items 20
```

### Step 5 - Upload the training data

Run:

```bash
bash scripts/02_upload_data.sh
```

Expected S3 objects:

```text
s3://<your-generated-bucket>/data/train.csv
s3://<your-generated-bucket>/data/validation.csv
```

The data is a small, prepared, binary subset of the Iris flower dataset. Each row is a label followed by four numeric features. The label is in the first CSV column, as required by the XGBoost built-in algorithm in CSV training mode.

No Python data-science libraries are needed to generate the data; the CSV files are included in this lab package.

### Step 6 - Create and run the SageMaker Pipeline

Make sure the virtual environment is active:

```bash
source .venv/bin/activate
python scripts/03_create_pipeline.py
```

What the script does:

1. Checks that both S3 data files exist.
2. Creates a pipeline with the `MaxDepth` parameter.
3. Adds a **TrainIrisModel** training step using the SageMaker XGBoost built-in algorithm on one `ml.m5.large` instance.
4. Adds a **RegisterIrisModel** step that registers the model in the Model Registry with status `PendingManualApproval`.
5. Starts the pipeline twice: once with `MaxDepth=3`, and once with `MaxDepth=5`.
6. Waits for both executions to finish and saves the model package ARNs to `model_packages.json`.

The pipeline is intentionally small. The two executions differ in one hyperparameter so participants can see how a repeatable pipeline creates separate model versions.

Expected result:

```text
Pipeline created/updated: <your-stack-name>-pipeline
...
SUCCESS: two pipeline executions completed and two model versions were registered.
Version <n>: PendingManualApproval - arn:aws:sagemaker:...
Version <n+1>: PendingManualApproval - arn:aws:sagemaker:...
```

Exact version numbers depend on whether the model group has prior versions. In this lab, the CloudFormation stack creates a new model group.

### Step 7 - Review and approve the model versions

1. In the AWS Console, open **Amazon SageMaker AI** in the same region.
2. In the navigation pane, open **Model Registry**.
3. Open the model package group whose name is shown in `.env` as `MODEL_PACKAGE_GROUP`.
4. Open each of the two model package versions.
5. Confirm that both are associated with the Day 9 pipeline and have status `PendingManualApproval`.
6. For this learning exercise, choose **Approve** for both versions.

Why this matters: training a model does not automatically mean that it should be deployed. The registry creates a governance checkpoint where a person or a policy can review the model before release.

If the Console menu differs in the selected SageMaker experience, the equivalent API operation is `UpdateModelPackage` with `ModelApprovalStatus=Approved`. Do not approve packages until the two versions have been created by the lab pipeline.

### Step 8 - Deploy version 1 and test it

Back in CloudShell, ensure the virtual environment is active and run:

```bash
source .venv/bin/activate
python scripts/04_deploy_and_bluegreen_update.py
```

The script:

1. Confirms that the two model package versions are approved.
2. Creates a SageMaker model from the first package version.
3. Creates an endpoint configuration using one `ml.m5.large` instance.
4. Creates a real-time endpoint and waits for `InService`.
5. Sends one sample CSV request to the endpoint and prints the model response.

The script then creates a second model and endpoint configuration from the second package version and updates the **same endpoint** using SageMaker's default managed blue/green deployment. When no custom `DeploymentConfig` is supplied, SageMaker defaults to blue/green with all-at-once traffic shifting.

It waits for the update to finish, invokes the endpoint again and records resource names in `resources.json` for cleanup.

**What blue/green means here:** SageMaker brings up a new (green) fleet while the old (blue) fleet remains available, shifts traffic to the new fleet according to the selected strategy, and then terminates the old fleet after the deployment wait period. The practical uses the SageMaker default blue/green update with all-at-once traffic shifting. It does not configure custom deployment guardrails, CloudWatch alarms or automatic alarm-triggered rollback. In production, configure and test CloudWatch alarms and an explicit rollback configuration before relying on automatic rollback.

### Step 9 - Confirm success

A successful run shows:

- The initial endpoint entered `InService`.
- The first invocation returned a numeric prediction.
- The endpoint update completed.
- The second invocation returned a numeric prediction.
- `resources.json` contains the endpoint, models, endpoint configurations and model package ARNs.

The numeric prediction is model-dependent. Do not expect a specific exact decimal value.

### Step 10 - Clean up all resources created by the lab

**Do not skip cleanup.** A real-time SageMaker endpoint incurs charges while it is running.

Run:

```bash
source .venv/bin/activate
python scripts/05_cleanup.py
```

The cleanup script deletes the endpoint first, then endpoint configurations, models, pipeline, model package versions, model package group, S3 objects and finally the CloudFormation stack (which deletes the bucket and execution role). SageMaker training-job history may remain visible after cleanup, but completed training jobs do not keep compute running.

Wait for the script to print `SUCCESS: lab-created resources have been deleted.` Confirm the CloudFormation stack is gone:

```bash
aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$AWS_REGION"
```

Expected after successful deletion: CloudFormation returns a `ValidationError` indicating the stack does not exist.

If a previous command failed before `resources.json` was written, use the SageMaker Console to delete any endpoint/model/endpoint configuration created by the failed attempt before deleting the stack. Do not delete the stack while SageMaker resources still reference its role or Model Registry group.

## 6. Troubleshooting

- **`Unable to locate credentials`:** CloudShell is not using the intended console identity. Run `aws sts get-caller-identity` and reopen CloudShell from the intended account.
- **Region is blank:** set `AWS_REGION` to the same Region selected in the Console.
- **CloudFormation `AccessDenied`:** the caller cannot create the stack resources or IAM roles. Check CloudFormation/IAM permissions, permission boundaries and organization SCPs.
- **`iam:PassRole` denied:** the caller cannot pass the generated execution role to SageMaker. Ask the account administrator to grant `iam:PassRole` on this lab role.
- **S3 `AccessDenied`:** check the bucket name in `.env`, the participant's S3 upload permission, and the inline policy on the stack-created execution role.
- **SDK installation fails:** check Python 3.11, pip output and CloudShell network controls.
- **XGBoost image unavailable:** confirm that the chosen Region supports the pinned algorithm image. Do not change image versions without retesting.
- **Training job quota error:** check SageMaker training quotas for `ml.m5.large` in the selected Region.
- **Endpoint quota/capacity error:** check real-time endpoint quota and regional capacity for the blue/green update. Do not repeatedly retry before resolving the capacity issue.
- **Endpoint is `Failed`:** inspect the endpoint failure reason in SageMaker Console and the associated CloudWatch logs.
- **Model package is still pending:** approve both versions in Model Registry before rerunning the deployment script.

## 7. Cost and safety notes

- The lab creates SageMaker training jobs, a real-time endpoint, S3 objects, IAM resources and a Model Registry group.
- The pinned XGBoost built-in algorithm image is `3.0-5`. AWS lists its end-of-patch date as **17 November 2026**. If the class takes place on or after that date, update the image version to a then-supported algorithm-mode release and repeat the end-to-end rehearsal before class.
- The endpoint is the most important resource to remove promptly. Billing depends on the selected AWS Region and instance type; check the current AWS pricing page for the region before class.
- Use a temporary training account or isolated sandbox. Do not deploy this broad training role in a production account.
- The CloudFormation template blocks public access and encrypts the S3 bucket with S3-managed encryption (SSE-S3).
- The stack is designed for deletion after the lab. The cleanup script empties the bucket before deleting the stack.

## 8. Knowledge check

1. What problem does a SageMaker Pipeline solve compared with manually starting training jobs?
2. What is the difference between a training job and a model package version?
3. Why is a model registered as `PendingManualApproval`?
4. What is the purpose of a Model Package Group?
5. Why do we keep the old fleet while a blue/green update is happening?
6. What would you add in production to support automatic rollback?
7. Where would MLflow fit into this lifecycle?
8. Where would KServe fit if the organization serves models on Kubernetes?

## 9. Expected architecture

```text
Prepared CSV data
       |
       v
   Amazon S3
       |
       v
SageMaker Pipeline
       |
       +--> Step 1: Train XGBoost model
       |
       +--> Step 2: Register model package
                    |
                    v
             Model Registry
                    |
             Manual approval
                    |
          +---------+---------+
          |                   |
          v                   v
      Model v1             Model v2
          |                   |
          v                   v
     Endpoint config 1   Endpoint config 2
          |                   |
          +------ Blue/Green -+
                    |
                    v
            SageMaker Endpoint
                    |
                    v
              Prediction
```

## 10. Reference documentation

- SageMaker Python SDK V3 - end-to-end pipeline with Model Registry: https://sagemaker.readthedocs.io/en/stable/v3-examples/ml-ops-examples/v3-pipeline-train-create-registry.html
- SageMaker XGBoost algorithm and supported versions: https://docs.aws.amazon.com/sagemaker/latest/dg/xgboost.html
- SageMaker execution roles and passing roles: https://docs.aws.amazon.com/sagemaker/latest/dg/sagemaker-roles.html
- SageMaker Model Registry: https://docs.aws.amazon.com/sagemaker/latest/dg/model-registry.html
- SageMaker blue/green all-at-once deployment: https://docs.aws.amazon.com/sagemaker/latest/dg/deployment-guardrails-blue-green-all-at-once.html
- AWS CloudShell environment: https://docs.aws.amazon.com/cloudshell/latest/userguide/vm-specs.html
