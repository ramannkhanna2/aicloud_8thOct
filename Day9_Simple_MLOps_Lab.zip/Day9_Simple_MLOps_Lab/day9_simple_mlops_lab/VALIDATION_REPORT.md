# Validation Report - Day 9 Simple MLOps Lab

**Validation date:** 2026-11-03  
**Status:** Static/local validation complete; live AWS acceptance test not performed.

## What was validated locally

- Python syntax compilation for the lab Python scripts.
- Bash syntax parsing for the shell scripts.
- CSV files contain 80 training rows and 20 validation rows; each row has five numeric fields (binary label + four features).
- CSV labels are limited to `0` and `1`.
- CloudFormation YAML parses when CloudFormation intrinsic tags (`!Sub`, `!GetAtt`, `!Ref`) are treated as tags.
- Boto3 API model in the local environment exposes the key fields used by the endpoint operations: `CreateModel.PrimaryContainer.ModelPackageName`, `CreateEndpointConfig.ProductionVariants`, and the `UpdateEndpoint` request shape. The script omits a custom deployment configuration so SageMaker applies its documented default blue/green all-at-once strategy.
- The SageMaker SDK code structure was checked against the published SageMaker Python SDK V3 end-to-end pipeline example, including `ModelTrainer`, `TrainingStep`, `ModelBuilder.register`, `ModelStep`, `Pipeline.upsert`, and pipeline execution patterns.
- The CloudFormation output for `ModelPackageGroupName` uses the stack-name substitution rather than a non-existent `GetAtt` attribute.
- The endpoint update script uses the SageMaker default blue/green update behavior (all-at-once) by omitting a custom `DeploymentConfig`.


## What has not been validated

No AWS credentials are available in the authoring environment. Consequently these have **not** been executed end-to-end:

- CloudFormation deployment in a real participant account.
- IAM role creation and `iam:PassRole` permissions under the account's SCP/permission boundary.
- S3 upload/read using the generated role.
- SageMaker XGBoost training job in the chosen training Region.
- SageMaker Pipeline execution and registration of both model package versions.
- Manual model approval in the AWS Console.
- SageMaker endpoint creation, invocation and blue/green update.
- Full cleanup and stack deletion in AWS.

The local container does not have SageMaker Python SDK V3.28.0 installed and internet is disabled, so SDK runtime imports were not executed here. The lab uses the official SageMaker SDK V3 pipeline pattern and pins the package to 3.28.0 for reproducibility. Package metadata currently lists Python 3.10, 3.11 and 3.12 as tested versions.

## Required pre-class live acceptance test

A trainer/admin must run the entire README on a fresh account/stack in the exact region used for training. All checks below must pass:

| Check | Pass condition |
|---|---|
| CloudShell identity | `aws sts get-caller-identity` returns the intended training account/identity |
| Region | Same region in console, CloudShell and all SageMaker resources |
| Python | Python 3.11 venv active |
| SDK | `sagemaker.__version__` prints `3.28.0` |
| CloudFormation | Stack reaches `CREATE_COMPLETE` |
| S3 | `train.csv` and `validation.csv` objects exist |
| Pipeline | Pipeline exists and definition has Train + Register steps |
| Run 1 | Execution reaches `Succeeded` and creates a Model Package version |
| Run 2 | Execution reaches `Succeeded` and creates another version |
| Registry | Both versions show `PendingManualApproval`, then both become `Approved` after review |
| Endpoint v1 | Endpoint reaches `InService`; sample invocation returns a prediction |
| Blue/green update | Update completes; endpoint returns to `InService`; second invocation returns a prediction |
| Cleanup | Endpoint, model configs, model package versions, model group, pipeline, bucket, role and stack are removed |

## Known limits

- The exercise uses a small binary Iris subset and does not teach model science or data preparation.
- The endpoint rollout relies on SageMaker's default blue/green all-at-once update behavior. It does not configure custom deployment guardrails or CloudWatch alarms, so automated alarm-triggered rollback is intentionally not claimed as part of the practical.
- MLflow, KServe and CodePipeline/CodeBuild are discussed as integration choices but are not built hands-on in this time-boxed core lab.
- `ml.m5.large` quota and regional availability can differ. The training account must have one training instance and enough concurrent endpoint quota for blue and green fleets during update.
- AWS service start times vary. Four-hour feasibility is a target based on a rehearsed account, not an unconditional guarantee.

## Official references used for technical design

1. SageMaker SDK V3 end-to-end pipeline with Model Registry: https://sagemaker.readthedocs.io/en/stable/v3-examples/ml-ops-examples/v3-pipeline-train-create-registry.html
2. SageMaker Python SDK 3.28.0 release information: https://github.com/aws/sagemaker-python-sdk/releases
3. SageMaker XGBoost algorithm: https://docs.aws.amazon.com/sagemaker/latest/dg/xgboost.html
4. SageMaker prebuilt container support policy: https://docs.aws.amazon.com/sagemaker/latest/dg/pre-built-containers-support-policy.html
5. SageMaker execution roles and passing roles: https://docs.aws.amazon.com/sagemaker/latest/dg/sagemaker-roles.html
6. SageMaker blue/green all-at-once deployment: https://docs.aws.amazon.com/sagemaker/latest/dg/deployment-guardrails-blue-green-all-at-once.html
7. AWS CloudShell environment: https://docs.aws.amazon.com/cloudshell/latest/userguide/vm-specs.html
