#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
STACK_NAME="${STACK_NAME:-day9-mlops-lab}"
REGION="${AWS_REGION:-${AWS_DEFAULT_REGION:-$(aws configure get region 2>/dev/null || true)}}"

# Keep all generated IAM, SageMaker model and endpoint names within service limits.
if [[ ${#STACK_NAME} -gt 32 || ! "$STACK_NAME" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?$ ]]; then
  echo "ERROR: STACK_NAME must be 1-32 characters, lowercase letters/numbers/hyphens, and start/end with a letter or number."
  echo "Example: export STACK_NAME=day9-learner01"
  exit 1
fi

if [[ -z "${REGION}" || "${REGION}" == "None" ]]; then
  echo "ERROR: AWS region is not set. Set AWS_REGION to the region selected in the AWS Console."
  echo "Example: export AWS_REGION=ap-south-1"
  exit 1
fi

command -v aws >/dev/null || { echo "ERROR: AWS CLI is not available in this terminal."; exit 1; }
aws sts get-caller-identity --region "$REGION" >/dev/null

echo "Using AWS region: $REGION"
echo "Using AWS identity:"
aws sts get-caller-identity --region "$REGION" --output table

echo "Creating the lab S3 bucket, SageMaker execution role, and Model Registry group..."
aws cloudformation deploy \
  --template-file "$ROOT_DIR/infrastructure/day9-mlops-stack.yaml" \
  --stack-name "$STACK_NAME" \
  --capabilities CAPABILITY_NAMED_IAM \
  --region "$REGION"

OUTPUTS="$(aws cloudformation describe-stacks --stack-name "$STACK_NAME" --region "$REGION" --query 'Stacks[0].Outputs' --output json)"
BUCKET_NAME="$(python3 -c 'import json,sys; d=json.load(sys.stdin); print(next(x["OutputValue"] for x in d if x["OutputKey"]=="LabBucketName"))' <<< "$OUTPUTS")"
ROLE_ARN="$(python3 -c 'import json,sys; d=json.load(sys.stdin); print(next(x["OutputValue"] for x in d if x["OutputKey"]=="SageMakerExecutionRoleArn"))' <<< "$OUTPUTS")"
MODEL_GROUP="$(python3 -c 'import json,sys; d=json.load(sys.stdin); print(next(x["OutputValue"] for x in d if x["OutputKey"]=="ModelPackageGroupName"))' <<< "$OUTPUTS")"

cat > "$ROOT_DIR/.env" <<EOF
AWS_REGION=$REGION
STACK_NAME=$STACK_NAME
BUCKET_NAME=$BUCKET_NAME
ROLE_ARN=$ROLE_ARN
MODEL_PACKAGE_GROUP=$MODEL_GROUP
PIPELINE_NAME=${STACK_NAME}-pipeline
ENDPOINT_BASE_NAME=${STACK_NAME}-endpoint
TRAIN_S3_URI=s3://$BUCKET_NAME/data/train.csv
VALIDATION_S3_URI=s3://$BUCKET_NAME/data/validation.csv
EOF

echo
echo "SUCCESS: participant infrastructure created."
echo "Bucket: $BUCKET_NAME"
echo "Execution role: $ROLE_ARN"
echo "Model group: $MODEL_GROUP"
echo "Configuration saved to $ROOT_DIR/.env"
