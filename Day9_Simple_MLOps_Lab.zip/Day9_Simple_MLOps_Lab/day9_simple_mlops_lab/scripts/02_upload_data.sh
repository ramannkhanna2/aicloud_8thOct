#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [[ ! -f "$ROOT_DIR/.env" ]]; then echo "ERROR: run scripts/01_setup.sh first."; exit 1; fi
# shellcheck disable=SC1091
source "$ROOT_DIR/.env"
aws s3 cp "$ROOT_DIR/data/train.csv" "$TRAIN_S3_URI" --region "$AWS_REGION"
aws s3 cp "$ROOT_DIR/data/validation.csv" "$VALIDATION_S3_URI" --region "$AWS_REGION"
echo "SUCCESS: data uploaded."
aws s3 ls "s3://$BUCKET_NAME/data/" --region "$AWS_REGION"
