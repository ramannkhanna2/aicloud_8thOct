#!/usr/bin/env python3
"""Create and run a small SageMaker Pipeline twice, registering two versions."""
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import boto3
from sagemaker.core import image_uris
from sagemaker.core.workflow.parameters import ParameterString
from sagemaker.core.workflow.pipeline_context import PipelineSession
from sagemaker.mlops.workflow.model_step import ModelStep
from sagemaker.mlops.workflow.pipeline import Pipeline
from sagemaker.mlops.workflow.steps import TrainingStep
from sagemaker.serve.model_builder import ModelBuilder
from sagemaker.train import ModelTrainer
from sagemaker.train.configs import Compute, InputData

ROOT = Path(__file__).resolve().parents[1]
ENV_FILE = ROOT / ".env"


def read_env(path: Path) -> dict:
    if not path.exists():
        raise SystemExit("Missing .env. Run scripts/01_setup.sh and scripts/02_upload_data.sh first.")
    result = {}
    for line in path.read_text().splitlines():
        if line.strip() and not line.lstrip().startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            result[key.strip()] = value.strip()
    return result


def wait_for_execution(client, arn: str, timeout_seconds: int = 2400) -> dict:
    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        result = client.describe_pipeline_execution(PipelineExecutionArn=arn)
        status = result["PipelineExecutionStatus"]
        print(f"  Pipeline status: {status}")
        if status == "Succeeded":
            return result
        if status in {"Failed", "Stopped"}:
            raise RuntimeError(f"Pipeline execution {status}: {result.get('FailureReason', 'No reason returned')}")
        time.sleep(15)
    raise TimeoutError(f"Pipeline execution exceeded {timeout_seconds} seconds: {arn}")


def list_all_packages(client, group_name: str) -> list:
    packages = []
    token = None
    while True:
        args = {"ModelPackageGroupName": group_name, "SortBy": "CreationTime", "SortOrder": "Ascending", "MaxResults": 100}
        if token:
            args["NextToken"] = token
        page = client.list_model_packages(**args)
        packages.extend(page.get("ModelPackageSummaryList", []))
        token = page.get("NextToken")
        if not token:
            return packages


def main() -> None:
    cfg = read_env(ENV_FILE)
    region = cfg["AWS_REGION"]
    bucket = cfg["BUCKET_NAME"]
    role_arn = cfg["ROLE_ARN"]
    group_name = cfg["MODEL_PACKAGE_GROUP"]
    pipeline_name = cfg["PIPELINE_NAME"]

    boto_session = boto3.Session(region_name=region)
    sm = boto_session.client("sagemaker")
    s3 = boto_session.client("s3")

    # Check the exact input objects before asking SageMaker to start paid training jobs.
    for key in ("data/train.csv", "data/validation.csv"):
        s3.head_object(Bucket=bucket, Key=key)

    # Explicitly use the lab bucket. The SDK must not silently create another default bucket.
    pipeline_session = PipelineSession(boto_session=boto_session, default_bucket=bucket)

    # XGBoost 3.0-5 is the selected built-in algorithm image for this dated lab release.
    # AWS lists its end-of-patch date as 2026-11-17; update and rehearse after that date.
    xgb_image = image_uris.retrieve(framework="xgboost", region=region, version="3.0-5")
    print(f"Training/inference image: {xgb_image}")

    max_depth = ParameterString(name="MaxDepth", default_value="3")

    trainer = ModelTrainer(
        training_image=xgb_image,
        role=role_arn,
        compute=Compute(instance_type="ml.m5.large", instance_count=1),
        base_job_name="day9-iris-xgb",
        sagemaker_session=pipeline_session,
        hyperparameters={
            "objective": "binary:logistic",
            "eval_metric": "auc",
            "num_round": 30,
            "max_depth": max_depth,
            "eta": 0.2,
            "verbosity": 0,
        },
        input_data_config=[
            InputData(channel_name="train", data_source=cfg["TRAIN_S3_URI"], content_type="text/csv"),
            InputData(channel_name="validation", data_source=cfg["VALIDATION_S3_URI"], content_type="text/csv"),
        ],
    )

    training_args = trainer.train()
    training_step = TrainingStep(name="TrainIrisModel", step_args=training_args)

    model_builder = ModelBuilder(
        s3_model_data_url=training_step.properties.ModelArtifacts.S3ModelArtifacts,
        image_uri=xgb_image,
        sagemaker_session=pipeline_session,
        role_arn=role_arn,
    )
    register_step = ModelStep(
        name="RegisterIrisModel",
        step_args=model_builder.register(
            model_package_group_name=group_name,
            content_types=["text/csv"],
            response_types=["text/csv"],
            inference_instances=["ml.m5.large"],
            transform_instances=["ml.m5.large"],
            approval_status="PendingManualApproval",
        ),
    )

    pipeline = Pipeline(
        name=pipeline_name,
        parameters=[max_depth],
        steps=[training_step, register_step],
        sagemaker_session=pipeline_session,
    )
    pipeline.upsert(role_arn=role_arn)
    print(f"Pipeline created/updated: {pipeline_name}")

    executions = []
    for depth in ("3", "5"):
        display_name = f"iris-depth-{depth}-{datetime.now(timezone.utc).strftime('%Y%m%d-%H%M%S')}"
        print(f"\nStarting pipeline with MaxDepth={depth}. This starts one SageMaker training job.")
        started = sm.start_pipeline_execution(
            PipelineName=pipeline_name,
            PipelineParameters=[{"Name": "MaxDepth", "Value": depth}],
            PipelineExecutionDisplayName=display_name,
        )
        arn = started["PipelineExecutionArn"]
        final = wait_for_execution(sm, arn)
        executions.append({"max_depth": depth, "execution_arn": arn, "status": final["PipelineExecutionStatus"]})
        print(f"Completed execution: {arn}")

    all_packages = list_all_packages(sm, group_name)
    # Filter to packages tagged by this lab's pipeline creation window through creation ordering.
    if len(all_packages) < 2:
        raise RuntimeError(f"Expected at least two model package versions in {group_name}; found {len(all_packages)}")
    latest = all_packages[-2:]
    package_records = [
        {
            "version": item["ModelPackageVersion"],
            "arn": item["ModelPackageArn"],
            "status": item.get("ModelApprovalStatus", "PendingManualApproval"),
            "created": item["CreationTime"].isoformat() if item.get("CreationTime") else "",
        }
        for item in latest
    ]
    output = {
        "pipeline_name": pipeline_name,
        "model_package_group": group_name,
        "executions": executions,
        "model_packages": package_records,
    }
    (ROOT / "model_packages.json").write_text(json.dumps(output, indent=2))

    print("\nSUCCESS: two pipeline executions completed and two model versions were registered.")
    for item in package_records:
        print(f"  Version {item['version']}: {item['status']} - {item['arn']}")
    print("Next: review both versions in SageMaker Model Registry and approve them for deployment.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise
