#!/usr/bin/env python3
"""Deploy model package v1 and update the endpoint to v2 with blue/green."""
import json
import sys
import time
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

ROOT = Path(__file__).resolve().parents[1]


def read_key_values(path: Path) -> dict:
    if not path.exists():
        raise SystemExit("Missing .env. Run scripts/01_setup.sh first.")
    result = {}
    for line in path.read_text().splitlines():
        if line.strip() and not line.lstrip().startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            result[key.strip()] = value.strip()
    return result


def save_progress(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, indent=2))


def wait_endpoint(sm, endpoint: str) -> None:
    sm.get_waiter("endpoint_in_service").wait(
        EndpointName=endpoint,
        WaiterConfig={"Delay": 15, "MaxAttempts": 80},
    )


def require_approved(sm, package_arn: str) -> None:
    status = sm.describe_model_package(ModelPackageName=package_arn).get("ModelApprovalStatus")
    if status != "Approved":
        raise RuntimeError(f"Model package {package_arn} is {status}, not Approved. Approve it in Model Registry first.")


def invoke(runtime, endpoint: str) -> None:
    response = runtime.invoke_endpoint(
        EndpointName=endpoint,
        ContentType="text/csv",
        Accept="text/csv",
        Body="5.1,3.5,1.4,0.2",
    )
    print("Sample prediction:", response["Body"].read().decode("utf-8").strip())


def main() -> None:
    cfg = read_key_values(ROOT / ".env")
    package_file = ROOT / "model_packages.json"
    if not package_file.exists():
        raise SystemExit("Missing model_packages.json. Run scripts/03_create_pipeline.py first.")
    package_data = json.loads(package_file.read_text())
    packages = sorted(package_data["model_packages"], key=lambda item: int(item["version"]))
    if len(packages) < 2:
        raise SystemExit("At least two registered versions are required.")

    region = cfg["AWS_REGION"]
    role_arn = cfg["ROLE_ARN"]
    sm = boto3.client("sagemaker", region_name=region)
    runtime = boto3.client("sagemaker-runtime", region_name=region)
    package_v1, package_v2 = packages[-2], packages[-1]
    require_approved(sm, package_v1["arn"])
    require_approved(sm, package_v2["arn"])

    suffix = time.strftime("%m%d%H%M%S", time.gmtime())
    endpoint = f"{cfg['ENDPOINT_BASE_NAME']}-{suffix}"
    tracked = {
        "endpoint_name": endpoint,
        "model_names": [],
        "endpoint_config_names": [],
        "model_package_arns": [package_v1["arn"], package_v2["arn"]],
        "pipeline_name": package_data["pipeline_name"],
        "model_package_group": package_data["model_package_group"],
    }
    resources_file = ROOT / "resources.json"
    save_progress(resources_file, tracked)

    def make_model_config(package, label):
        model_name = f"{cfg['ENDPOINT_BASE_NAME']}-{label}-model-{suffix}"
        config_name = f"{cfg['ENDPOINT_BASE_NAME']}-{label}-config-{suffix}"
        sm.create_model(
            ModelName=model_name,
            ExecutionRoleArn=role_arn,
            PrimaryContainer={"ModelPackageName": package["arn"]},
        )
        tracked["model_names"].append(model_name)
        save_progress(resources_file, tracked)
        sm.create_endpoint_config(
            EndpointConfigName=config_name,
            ProductionVariants=[
                {
                    "VariantName": "AllTraffic",
                    "ModelName": model_name,
                    "InitialInstanceCount": 1,
                    "InstanceType": "ml.m5.large",
                    "InitialVariantWeight": 1.0,
                }
            ],
        )
        tracked["endpoint_config_names"].append(config_name)
        save_progress(resources_file, tracked)
        return config_name

    print("Creating first model endpoint (version 1)...")
    config_v1 = make_model_config(package_v1, "v1")
    sm.create_endpoint(EndpointName=endpoint, EndpointConfigName=config_v1)
    save_progress(resources_file, tracked)
    wait_endpoint(sm, endpoint)
    print("Version 1 is InService. Invoking endpoint:")
    invoke(runtime, endpoint)

    print("Creating version 2 endpoint configuration...")
    config_v2 = make_model_config(package_v2, "v2")
    print("Updating the existing endpoint using SageMaker default blue/green (all-at-once) traffic shifting...")
    # Without a custom DeploymentConfig, SageMaker defaults to a managed
    # blue/green deployment with all-at-once traffic shifting.
    sm.update_endpoint(
        EndpointName=endpoint,
        EndpointConfigName=config_v2,
    )
    wait_endpoint(sm, endpoint)
    print("Version 2 is InService. Invoking endpoint:")
    invoke(runtime, endpoint)

    print("\nSUCCESS: endpoint updated from model package version "
          f"{package_v1['version']} to version {package_v2['version']}.")
    print(f"Endpoint name: {endpoint}")
    print("Resource inventory saved to resources.json for cleanup.")


if __name__ == "__main__":
    try:
        main()
    except ClientError as exc:
        print(f"AWS API error: {exc}", file=sys.stderr)
        raise
    except Exception as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise
