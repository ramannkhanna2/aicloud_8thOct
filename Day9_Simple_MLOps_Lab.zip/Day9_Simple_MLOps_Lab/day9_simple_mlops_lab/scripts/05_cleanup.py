#!/usr/bin/env python3
"""Remove resources created by the Day 9 lab. Run after the endpoint exercise."""
import json
import sys
import time
from pathlib import Path

import boto3
from botocore.exceptions import ClientError

ROOT = Path(__file__).resolve().parents[1]


def read_env() -> dict:
    path = ROOT / ".env"
    if not path.exists():
        raise SystemExit("Missing .env; cannot identify lab resources.")
    result = {}
    for line in path.read_text().splitlines():
        if line.strip() and not line.lstrip().startswith("#") and "=" in line:
            key, value = line.split("=", 1)
            result[key.strip()] = value.strip()
    return result


def is_missing(exc: ClientError) -> bool:
    return exc.response.get("Error", {}).get("Code", "") in {
        "ResourceNotFound", "ResourceNotFoundException", "ValidationException",
        "NoSuchEntity", "404", "NotFound"
    }


def delete_model_packages(sm, group: str) -> None:
    # Deleting packages is eventually consistent; repeatedly request the first page.
    deadline = time.time() + 240
    while time.time() < deadline:
        page = sm.list_model_packages(ModelPackageGroupName=group, MaxResults=100)
        packages = page.get("ModelPackageSummaryList", [])
        if not packages:
            return
        for item in packages:
            arn = item["ModelPackageArn"]
            try:
                sm.delete_model_package(ModelPackageName=arn)
                print(f"Requested deletion of model package: {arn}")
            except ClientError as exc:
                if not is_missing(exc):
                    raise
        time.sleep(5)
    raise TimeoutError(f"Model packages in {group} did not finish deleting within four minutes.")


def main() -> None:
    cfg = read_env()
    region = cfg["AWS_REGION"]
    sm = boto3.client("sagemaker", region_name=region)
    s3 = boto3.resource("s3", region_name=region)
    cf = boto3.client("cloudformation", region_name=region)

    resources_path = ROOT / "resources.json"
    if resources_path.exists():
        resources = json.loads(resources_path.read_text())
        endpoint = resources.get("endpoint_name")
        if endpoint:
            try:
                sm.describe_endpoint(EndpointName=endpoint)
                print(f"Deleting endpoint: {endpoint}")
                sm.delete_endpoint(EndpointName=endpoint)
                sm.get_waiter("endpoint_deleted").wait(
                    EndpointName=endpoint,
                    WaiterConfig={"Delay": 15, "MaxAttempts": 80},
                )
            except ClientError as exc:
                if not is_missing(exc):
                    raise

        for config_name in resources.get("endpoint_config_names", []):
            try:
                sm.delete_endpoint_config(EndpointConfigName=config_name)
                print(f"Deleted endpoint configuration: {config_name}")
            except ClientError as exc:
                if not is_missing(exc):
                    raise

        for model_name in resources.get("model_names", []):
            try:
                sm.delete_model(ModelName=model_name)
                print(f"Deleted model: {model_name}")
            except ClientError as exc:
                if not is_missing(exc):
                    raise

    try:
        sm.delete_pipeline(PipelineName=cfg["PIPELINE_NAME"])
        print("Deleted SageMaker Pipeline.")
    except ClientError as exc:
        if not is_missing(exc):
            raise

    group = cfg["MODEL_PACKAGE_GROUP"]
    try:
        delete_model_packages(sm, group)
        sm.delete_model_package_group(ModelPackageGroupName=group)
        print("Deleted SageMaker Model Package Group.")
    except ClientError as exc:
        if not is_missing(exc):
            raise

    bucket = cfg["BUCKET_NAME"]
    print(f"Emptying S3 bucket: {bucket}")
    s3.Bucket(bucket).objects.all().delete()

    print(f"Deleting CloudFormation stack: {cfg['STACK_NAME']}")
    try:
        cf.delete_stack(StackName=cfg["STACK_NAME"])
        cf.get_waiter("stack_delete_complete").wait(
            StackName=cfg["STACK_NAME"],
            WaiterConfig={"Delay": 10, "MaxAttempts": 60},
        )
    except ClientError as exc:
        if not is_missing(exc):
            raise

    print("SUCCESS: lab endpoint, model resources, pipeline, model group, S3 bucket and execution role have been removed.")
    print("Completed SageMaker training-job history can remain visible; completed jobs do not keep compute running.")


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"CLEANUP ERROR: {exc}", file=sys.stderr)
        raise
